library(shiny)
predictApp = function(){
  runApp('shinyapp')
}